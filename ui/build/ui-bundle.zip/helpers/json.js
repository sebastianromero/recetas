'use strict'

module.exports = function (object) {
  return JSON.stringify(object, null, 2)
}
